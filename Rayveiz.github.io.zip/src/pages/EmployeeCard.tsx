import { useState, useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import { format, differenceInDays } from "date-fns";
import { ru } from "date-fns/locale";
import { CalendarIcon } from "lucide-react";
import Navbar from "@/components/Navbar";
import AnimatedBackground from "@/components/AnimatedBackground";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from "@/components/ui/table";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { ArrowLeft, Save, Upload, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";

// Shared employee data
const employeesData: Record<number, {
  name: string; position: string; status: string; grade: string;
  total90d: number; avgMonthly: number; needMonthly: number; planHours3m: number; progressPercent: number;
  photoUrl: string | null;
}> = {
  2733: { name: "Алексашкин Святослав Сергеевич", position: "Младший консультант по информационным технологиям", status: "1", grade: "Junior", total90d: 312.5, avgMonthly: 104.2, needMonthly: 120, planHours3m: 360, progressPercent: 87, photoUrl: null },
  2379: { name: "Болтнев Станислав Александрович", position: "Ведущий консультант по информационным технологиям", status: "3", grade: "Senior", total90d: 485.0, avgMonthly: 161.7, needMonthly: 140, planHours3m: 420, progressPercent: 115, photoUrl: null },
  2721: { name: "Ефремов Алексей Владимирович", position: "Ведущий консультант по информационным технологиям", status: "3", grade: "Senior", total90d: 410.5, avgMonthly: 136.8, needMonthly: 140, planHours3m: 420, progressPercent: 98, photoUrl: null },
  2365: { name: "Казаков Антон Вячеславович", position: "Аналитик", status: "1", grade: "Middle", total90d: 295.0, avgMonthly: 98.3, needMonthly: 120, planHours3m: 360, progressPercent: 82, photoUrl: null },
  2713: { name: "Лунев Никита", position: "Младший консультант по информационным технологиям", status: "2", grade: "Junior", total90d: 280.0, avgMonthly: 93.3, needMonthly: 120, planHours3m: 360, progressPercent: 78, photoUrl: null },
  2705: { name: "Петянов Леонид Станиславович", position: "Младший консультант по информационным технологиям", status: "2", grade: "Junior", total90d: 305.0, avgMonthly: 101.7, needMonthly: 120, planHours3m: 360, progressPercent: 85, photoUrl: null },
  2473: { name: "Пронина Ирина Михайловна", position: "Консультант по информационным технологиям", status: "1", grade: "Middle", total90d: 350.0, avgMonthly: 116.7, needMonthly: 120, planHours3m: 360, progressPercent: 97, photoUrl: null },
  1973: { name: "Пучков Олег Анатольевич", position: "Ведущий консультант по информационным технологиям", status: "3", grade: "Senior", total90d: 520.0, avgMonthly: 173.3, needMonthly: 140, planHours3m: 420, progressPercent: 124, photoUrl: null },
  2691: { name: "Садкова Виктория Александровна", position: "Младший консультант по информационным технологиям", status: "1", grade: "Junior", total90d: 260.0, avgMonthly: 86.7, needMonthly: 120, planHours3m: 360, progressPercent: 72, photoUrl: null },
  2175: { name: "Сокотун Ирина Олеговна", position: "Ведущий консультант по информационным технологиям", status: "2", grade: "Senior", total90d: 390.0, avgMonthly: 130.0, needMonthly: 140, planHours3m: 420, progressPercent: 93, photoUrl: null },
  2585: { name: "Хисматова Алина Руслановна", position: "Консультант по информационным технологиям", status: "2", grade: "Middle", total90d: 330.0, avgMonthly: 110.0, needMonthly: 120, planHours3m: 360, progressPercent: 92, photoUrl: null },
  2325: { name: "Шмырина Анастасия Анатольевна", position: "", status: "3", grade: "Middle", total90d: 370.0, avgMonthly: 123.3, needMonthly: 120, planHours3m: 360, progressPercent: 103, photoUrl: null },
  2819: { name: "Ярков Константин Владимирович", position: "", status: "3", grade: "Middle", total90d: 345.0, avgMonthly: 115.0, needMonthly: 120, planHours3m: 360, progressPercent: 96, photoUrl: null },
  2835: { name: "Ярышев Владимир Сергеевич", position: "", status: "1", grade: "Lead", total90d: 450.0, avgMonthly: 150.0, needMonthly: 140, planHours3m: 420, progressPercent: 107, photoUrl: null },
};

const statusLabels: Record<string, string> = { "1": "Свободен", "2": "Занят", "3": "Завал" };
const statusColors: Record<string, string> = {
  "1": "text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800",
  "2": "text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800",
  "3": "text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-950/50 border-red-200 dark:border-red-800",
};

// Mock tasks
const generateTasks = (empId: number) => {
  const configs = ["ERP Опер. Учет", "БП", "ЗУП", "УНФ", "CRM", "ДО", "УТ"];
  const types = ["Сопровождение", "Внедрение", "Обновление", "Консультация", "Доработка"];
  const statuses = ["Закрыта", "В работе", "На проверке"];
  const sources = ["Bitrix", "Jira", "Ручной ввод"];
  const tasks = [];
  const count = 15 + (empId % 10);
  for (let i = 0; i < count; i++) {
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * 90));
    tasks.push({
      id: empId * 100 + i,
      taskId: 10000 + Math.floor(Math.random() * 90000),
      hours: +(Math.random() * 8 + 0.5).toFixed(1),
      createdAt: date.toLocaleDateString("ru-RU"),
      source: sources[Math.floor(Math.random() * sources.length)],
      config: configs[Math.floor(Math.random() * configs.length)],
      taskType: types[Math.floor(Math.random() * types.length)],
      taskStatus: statuses[Math.floor(Math.random() * statuses.length)],
    });
  }
  return tasks;
};

const configSkills = ["УХ", "УПП", "ERP Опер. Учет", "ERP Рег. Учет", "ERP Бюджет", "ЗУП", "БП", "УТ", "УНФ", "ДО", "ТОиР", "ИТИЛ"];
const crmSkills = [
  "CRM: внедрение, доработки, сопровождение",
  "Документация и инструкции",
  "Обновления",
  "Обучение/ Передача знаний",
  "Оценка/ЧТЗ/ Спецификации",
  "Сбор требований/ предпроект",
  "Сопровождение: прочие обращения",
  "Тестирование",
  "Учет/ Хозяйственный блок",
];

const cellColor = (val: number, max: number) => {
  if (val === 0) return "text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-950/40";
  if (max === 3) {
    if (val === 1) return "text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/40";
    if (val === 2) return "text-yellow-600 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-950/40";
    return "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 font-bold";
  }
  if (val === 1) return "text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/40";
  if (val === 2) return "text-yellow-600 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-950/40";
  if (val === 3) return "text-lime-600 dark:text-lime-400 bg-lime-50 dark:bg-lime-950/40 font-semibold";
  return "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 font-bold";
};
const EmployeeCard = () => {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const empId = parseInt(id || "0");
  const emp = employeesData[empId];

  const [dateFrom, setDateFrom] = useState<Date>(() => {
    const d = new Date(); d.setDate(d.getDate() - 90); return d;
  });
  const [dateTo, setDateTo] = useState<Date>(new Date());
  const [grade, setGrade] = useState(emp?.grade || "Middle");
  const [devPlan, setDevPlan] = useState<{ goal: string; deadline: string }[]>([
    { goal: "", deadline: "" },
  ]);
  const [compMode, setCompMode] = useState<"config" | "crm">("config");
  const [searchQuery, setSearchQuery] = useState("");
  const [configFilter, setConfigFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const [employeeType, setEmployeeType] = useState("Процессный исполнитель");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [compScores, setCompScores] = useState<Record<string, number>>(() => {
    const scores: Record<string, number> = {};
    [...configSkills, ...crmSkills].forEach(s => { scores[s] = Math.floor(Math.random() * 4); });
    return scores;
  });

  const tasks = useMemo(() => generateTasks(empId), [empId]);

  const filteredTasks = useMemo(() => {
    return tasks.filter(t => {
      if (searchQuery && !t.taskId.toString().includes(searchQuery) && !t.config.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (configFilter !== "all" && t.config !== configFilter) return false;
      if (typeFilter !== "all" && t.taskType !== typeFilter) return false;
      if (statusFilter !== "all" && t.taskStatus !== statusFilter) return false;
      return true;
    });
  }, [tasks, searchQuery, configFilter, typeFilter, statusFilter]);

  const configOptions = [...new Set(tasks.map(t => t.config))];
  const typeOptions = [...new Set(tasks.map(t => t.taskType))];
  const statusOptions = [...new Set(tasks.map(t => t.taskStatus))];

  const activeSkills = compMode === "config" ? configSkills : crmSkills;
  const maxScore = compMode === "config" ? 3 : 4;

  if (!emp) {
    return (
      <div className="min-h-screen relative">
        <AnimatedBackground />
        <div className="relative z-10 max-w-[1200px] mx-auto px-3 sm:px-6 py-4 sm:py-6">
          <Navbar />
          <div className="bg-card/80 backdrop-blur-md border border-border rounded-2xl p-8 text-center">
            <h1 className="text-xl font-bold text-foreground mb-2">Сотрудник не найден</h1>
            <Link to="/employees" className="text-primary hover:underline text-sm">← Назад к сотрудникам</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative">
      <AnimatedBackground />
      <div className="relative z-10 max-w-[1200px] mx-auto px-3 sm:px-6 py-4 sm:py-6">
        <Navbar />

        {/* Header */}
        <div className="bg-card/80 backdrop-blur-md border border-border rounded-2xl p-4 sm:p-6 mb-4 shadow-[0_4px_24px_rgba(0,0,0,0.06)]">
          <Link to="/employees" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-4">
            <ArrowLeft className="w-4 h-4" />
            Назад к сотрудникам
          </Link>
          <h1 className="text-xl sm:text-2xl font-bold text-foreground">
            Карточка сотрудника: {emp.name} ({empId})
          </h1>
        </div>

        {/* Profile + Output & Dev Plan */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          {/* Profile */}
          <div className="bg-card/80 backdrop-blur-md border border-border rounded-2xl shadow-[0_4px_24px_rgba(0,0,0,0.06)] overflow-hidden">
            {/* Profile header with gradient accent */}
            <div className="h-2 bg-gradient-to-r from-primary via-primary/70 to-primary/40" />
            <div className="p-4 sm:p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-foreground">Профиль</h2>
                <div className="flex items-center gap-1 bg-muted/50 rounded-full p-0.5 border border-border">
                  <button
                    onClick={() => setGender("male")}
                    className={cn(
                      "px-3 py-1 rounded-full text-xs font-medium transition-all",
                      gender === "male"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    ♂ Муж
                  </button>
                  <button
                    onClick={() => setGender("female")}
                    className={cn(
                      "px-3 py-1 rounded-full text-xs font-medium transition-all",
                      gender === "female"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    ♀ Жен
                  </button>
                </div>
              </div>

              {/* Photos & type row — moved to top */}
              <div className="flex gap-4 mb-5">
                {/* Employee photo */}
                <div className="flex flex-col items-center flex-1">
                  <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Фото</span>
                  {emp.photoUrl ? (
                    <img src={emp.photoUrl} alt="Фото" className="w-full aspect-square max-w-[160px] object-cover rounded-2xl border-2 border-border shadow-md mb-2" />
                  ) : (
                    <div className="w-full aspect-square max-w-[160px] rounded-2xl border-2 border-dashed border-border bg-gradient-to-br from-muted/40 to-muted/10 flex items-center justify-center mb-2 shadow-inner">
                      <User className="w-14 h-14 text-muted-foreground/20" />
                    </div>
                  )}
                  <p className="text-[10px] text-muted-foreground mb-2">
                    {emp.photoUrl ? "✓ Фото загружено" : "Фото отсутствует"}
                  </p>
                  <label className="cursor-pointer inline-flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 transition-colors bg-primary/5 hover:bg-primary/10 px-3 py-1.5 rounded-lg border border-primary/20">
                    <Upload className="w-3 h-3" />
                    Загрузить
                    <input type="file" accept=".jpg,.jpeg,.png,.webp" className="hidden" />
                  </label>
                </div>

                {/* Employee type */}
                <div className="flex flex-col items-center flex-1">
                  <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1 text-center">Тип сотрудника</span>
                  <span className="text-[10px] text-muted-foreground/70 mb-2">по результатам опроса</span>
                  <Select value={employeeType} onValueChange={setEmployeeType}>
                    <SelectTrigger className="w-full max-w-[200px] h-8 text-xs bg-background/80 border-border/60 rounded-lg mb-2"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Процессный исполнитель">Процессный исполнитель</SelectItem>
                      <SelectItem value="Надежный гибкий исполнитель">Надежный гибкий исполнитель</SelectItem>
                      <SelectItem value="Творческий исследователь">Творческий исследователь</SelectItem>
                      <SelectItem value="Автономный результатник">Автономный результатник</SelectItem>
                      <SelectItem value="Адаптивный координатор">Адаптивный координатор</SelectItem>
                      <SelectItem value="Сбалансированный исполнитель">Сбалансированный исполнитель</SelectItem>
                      <SelectItem value="Нужен контур управления">Нужен контур управления</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="w-full aspect-square max-w-[130px] rounded-2xl border-2 border-dashed border-border bg-gradient-to-br from-muted/30 to-transparent flex items-center justify-center mb-2">
                    <User className="w-10 h-10 text-muted-foreground/15" />
                  </div>
                  <textarea
                    placeholder="Описание типа..."
                    rows={2}
                    className="w-full text-xs rounded-xl border border-border/60 bg-background/60 px-3 py-2 text-foreground placeholder:text-muted-foreground/50 resize-none focus:outline-none focus:ring-1 focus:ring-primary/40"
                  />
                </div>
              </div>

              {/* Info cards — moved below */}
              <div className="space-y-2.5">
                <div className="flex items-start gap-3 bg-muted/30 rounded-xl px-3.5 py-2.5 border border-border/50">
                  <span className="text-xs text-muted-foreground whitespace-nowrap mt-0.5">Должность</span>
                  <span className="text-sm text-foreground font-medium ml-auto text-right">{emp.position || "—"}</span>
                </div>
                <div className="flex items-center gap-3 bg-muted/30 rounded-xl px-3.5 py-2.5 border border-border/50">
                  <span className="text-xs text-muted-foreground">Статус</span>
                  <span className={`ml-auto inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold border ${statusColors[emp.status]}`}>{statusLabels[emp.status]}</span>
                </div>
                <div className="flex items-center gap-3 bg-muted/30 rounded-xl px-3.5 py-2.5 border border-border/50">
                  <span className="text-xs text-muted-foreground">Грейд</span>
                  <Select value={grade} onValueChange={setGrade}>
                    <SelectTrigger className="ml-auto w-28 h-7 text-xs bg-background/80 border-border/60 rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Junior">Junior</SelectItem>
                      <SelectItem value="Middle">Middle</SelectItem>
                      <SelectItem value="Senior">Senior</SelectItem>
                      <SelectItem value="Lead">Lead</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>

          {/* Right column: Output + Dev Plan stacked */}
          <div className="flex flex-col gap-4">
            {/* Output */}
            <div className="bg-card/80 backdrop-blur-md border border-border rounded-2xl p-4 sm:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.06)]">
              <h2 className="text-lg font-semibold text-foreground mb-3">Выработка</h2>
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className={cn("h-8 text-xs justify-start gap-1.5", !dateFrom && "text-muted-foreground")}>
                      <CalendarIcon className="w-3.5 h-3.5" />
                      {dateFrom ? format(dateFrom, "dd.MM.yyyy") : "От"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={dateFrom} onSelect={(d) => d && setDateFrom(d)} initialFocus className="p-3 pointer-events-auto" locale={ru} />
                  </PopoverContent>
                </Popover>
                <span className="text-muted-foreground text-xs">—</span>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className={cn("h-8 text-xs justify-start gap-1.5", !dateTo && "text-muted-foreground")}>
                      <CalendarIcon className="w-3.5 h-3.5" />
                      {dateTo ? format(dateTo, "dd.MM.yyyy") : "До"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={dateTo} onSelect={(d) => d && setDateTo(d)} initialFocus className="p-3 pointer-events-auto" locale={ru} />
                  </PopoverContent>
                </Popover>
              </div>
              {(() => {
                const days = Math.max(differenceInDays(dateTo, dateFrom), 1);
                const factor = days / 90;
                const totalHours = +(emp.total90d * factor).toFixed(1);
                const months = Math.max(days / 30, 1);
                const avgMonthly = +(totalHours / months).toFixed(1);
                const planHours = +(emp.planHours3m * factor).toFixed(1);
                const progress = Math.round((totalHours / planHours) * 100);
                return (
                  <div className="space-y-3 text-sm">
                    <p className="text-muted-foreground">За {days} дн.: <span className="text-foreground font-bold text-lg">{totalHours} ч</span></p>
                    <p className="text-muted-foreground">Средняя выработка: <span className="text-foreground font-medium">{avgMonthly} ч/мес</span> <span className="text-xs">(минимум: {emp.needMonthly.toFixed(1)})</span></p>
                    <p className="text-muted-foreground">План: <span className="text-foreground font-medium">{planHours} ч</span></p>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-muted-foreground text-xs">Прогресс</span>
                        <span className={`text-sm font-bold ${progress >= 100 ? "text-emerald-600" : progress >= 80 ? "text-foreground" : "text-red-500"}`}>{progress}%</span>
                      </div>
                      <Progress value={Math.min(progress, 100)} className="h-3" />
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Development Plan */}
            <div className="bg-card/80 backdrop-blur-md border border-border rounded-2xl p-4 sm:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.06)] flex-1">
              <h2 className="text-lg font-semibold text-foreground mb-4">План развития</h2>
              <div className="rounded-xl border border-border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50 hover:bg-muted/50">
                      <TableHead className="font-bold text-foreground">Цель</TableHead>
                      <TableHead className="font-bold text-foreground w-40">Срок</TableHead>
                      <TableHead className="w-12" />
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {devPlan.map((row, i) => (
                      <TableRow key={i}>
                        <TableCell className="p-1.5">
                          <Input
                            value={row.goal}
                            onChange={e => {
                              const next = [...devPlan];
                              next[i] = { ...next[i], goal: e.target.value };
                              setDevPlan(next);
                            }}
                            placeholder="Описание цели..."
                            className="bg-background/70 text-sm h-8"
                          />
                        </TableCell>
                        <TableCell className="p-1.5">
                          <Input
                            type="date"
                            value={row.deadline}
                            onChange={e => {
                              const next = [...devPlan];
                              next[i] = { ...next[i], deadline: e.target.value };
                              setDevPlan(next);
                            }}
                            className="bg-background/70 text-sm h-8"
                          />
                        </TableCell>
                        <TableCell className="p-1.5 text-center">
                          {devPlan.length > 1 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                              onClick={() => setDevPlan(devPlan.filter((_, j) => j !== i))}
                            >
                              ×
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="mt-3 text-xs"
                onClick={() => setDevPlan([...devPlan, { goal: "", deadline: "" }])}
              >
                + Добавить цель
              </Button>
            </div>
          </div>
        </div>

        {/* Tasks */}
        <div className="bg-card/80 backdrop-blur-md border border-border rounded-2xl p-4 sm:p-6 mb-4 shadow-[0_4px_24px_rgba(0,0,0,0.06)]">
          <h2 className="text-lg font-semibold text-foreground mb-4">Задачи (учтенное время, последние 90 дней)</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
            <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Поиск..." className="bg-background/70" />
            <Select value={configFilter} onValueChange={setConfigFilter}>
              <SelectTrigger className="bg-background/70"><SelectValue placeholder="Конфигурация" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все конфигурации</SelectItem>
                {configOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="bg-background/70"><SelectValue placeholder="Тип" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все типы</SelectItem>
                {typeOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="bg-background/70"><SelectValue placeholder="Статус" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все статусы</SelectItem>
                {statusOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="text-xs text-muted-foreground self-center">
              Показано {filteredTasks.length} из {tasks.length}
            </div>
          </div>

          <div className="rounded-xl border border-border overflow-auto scrollbar-thin max-h-[400px]">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50 hover:bg-muted/50 sticky top-0 z-10">
                  <TableHead className="font-bold text-foreground w-16">ID</TableHead>
                  <TableHead className="font-bold text-foreground">Task ID</TableHead>
                  <TableHead className="font-bold text-foreground w-20">Часы</TableHead>
                  <TableHead className="font-bold text-foreground">Дата</TableHead>
                  <TableHead className="font-bold text-foreground">Источник</TableHead>
                  <TableHead className="font-bold text-foreground">Конфигурация</TableHead>
                  <TableHead className="font-bold text-foreground">Тип</TableHead>
                  <TableHead className="font-bold text-foreground">Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTasks.map(t => (
                  <TableRow key={t.id} className="transition-colors duration-200">
                    <TableCell className="font-mono text-muted-foreground text-xs">{t.id}</TableCell>
                    <TableCell className="font-mono text-muted-foreground text-sm">{t.taskId}</TableCell>
                    <TableCell className="font-medium text-foreground">{t.hours}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">{t.createdAt}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">{t.source}</TableCell>
                    <TableCell className="text-sm">{t.config}</TableCell>
                    <TableCell className="text-sm">{t.taskType}</TableCell>
                    <TableCell className="text-sm">{t.taskStatus}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>

        {/* Competency matrix */}
        <div className="bg-card/80 backdrop-blur-md border border-border rounded-2xl p-4 sm:p-6 shadow-[0_4px_24px_rgba(0,0,0,0.06)]">
          <h2 className="text-lg font-semibold text-foreground mb-3">Матрица компетенций</h2>

          <div className="flex gap-2 mb-4">
            <button
              onClick={() => setCompMode("config")}
              className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                compMode === "config"
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-secondary/70 text-secondary-foreground hover:bg-accent"
              }`}
            >
              По конфигурации (0–3)
            </button>
            <button
              onClick={() => setCompMode("crm")}
              className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                compMode === "crm"
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-secondary/70 text-secondary-foreground hover:bg-accent"
              }`}
            >
              По типам задач (0–4)
            </button>
          </div>

          <div className="rounded-xl border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50 hover:bg-muted/50">
                  <TableHead className="font-bold text-foreground">Навык</TableHead>
                  <TableHead className="font-bold text-foreground w-32 text-center">Оценка (0–{maxScore})</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeSkills.map(skill => (
                  <TableRow key={skill}>
                    <TableCell className="text-sm text-foreground">{skill}</TableCell>
                    <TableCell className="text-center p-2">
                      <input
                        type="number"
                        min={0}
                        max={maxScore}
                        value={compScores[skill] ?? 0}
                        onChange={e => setCompScores(prev => ({ ...prev, [skill]: parseInt(e.target.value) || 0 }))}
                        className={`w-14 h-8 text-center text-sm rounded-md border border-transparent hover:border-border focus:border-primary outline-none transition-all ${cellColor(compScores[skill] ?? 0, maxScore)}`}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="mt-4">
            <Button onClick={() => toast({ title: "Сохранено", description: "Матрица компетенций обновлена" })} className="gap-1.5 shadow-md w-full sm:w-auto">
              <Save className="w-4 h-4" />
              Сохранить матрицу
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeCard;
